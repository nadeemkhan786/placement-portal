<?php 
 //$state = $_GET['state']; echo $state; 
session_start();




$s=$_POST['location'];
echo $s;


 ?>